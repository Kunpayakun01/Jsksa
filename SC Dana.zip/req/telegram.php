<?php
$id_telegram = "5959308209";
$id_botTele  = "7107625201:AAFrOzngkIoTKwrn-GgctZjOvbGTRRARGnk";
?>
